package com.example.floattap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * Two floating buttons:
 *  - HANDLE (green, screen edge, thumb-reachable): press and HOLD it.
 *  - TARGET (red): placed on the video. While you hold the handle, the app holds a finger down on the target.
 * Instagram: hold on the right side of a Reel = 2x speed. Release the handle = back to 1x.
 */
class ClickService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private lateinit var handleView: View
    private lateinit var targetView: View
    private lateinit var handleLp: WindowManager.LayoutParams
    private lateinit var targetLp: WindowManager.LayoutParams
    private val ui = Handler(Looper.getMainLooper())

    private var holding = false
    private var stroke: GestureDescription.StrokeDescription? = null
    private var holdX = 0f
    private var holdY = 0f
    private val chunkMs = 200L
    private val startDelayMs = 120L   // lets you drag the handle without triggering a hold

    private val startHoldRunnable = Runnable { beginHold() }

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        val d = dm.density

        handleLp = newParams((72 * d).toInt(), dm.widthPixels - (72 * d).toInt(), (dm.heightPixels * 0.62).toInt())
        targetLp = newParams((56 * d).toInt(), (dm.widthPixels * 0.70).toInt(), (dm.heightPixels * 0.45).toInt())

        handleView = circle("#2E7D32", 0.55f)
        targetView = circle("#C62828", 0.85f)

        setupTarget()
        setupHandle()
        wm.addView(targetView, targetLp)
        wm.addView(handleView, handleLp)
    }

    private fun setupTarget() {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        targetView.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = targetLp.x; sy = targetLp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    targetLp.x = sx + (e.rawX - tx).toInt()
                    targetLp.y = sy + (e.rawY - ty).toInt()
                    wm.updateViewLayout(targetView, targetLp)
                }
            }
            true
        }
    }

    private fun setupHandle() {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var dragging = false
        handleView.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = handleLp.x; sy = handleLp.y; tx = e.rawX; ty = e.rawY; dragging = false
                    ui.postDelayed(startHoldRunnable, startDelayMs)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (!dragging && (abs(dx) > 25 || abs(dy) > 25)) {
                        dragging = true
                        ui.removeCallbacks(startHoldRunnable)
                        endHold()
                    }
                    if (dragging) {
                        handleLp.x = sx + dx.toInt(); handleLp.y = sy + dy.toInt()
                        wm.updateViewLayout(handleView, handleLp)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(startHoldRunnable)
                    endHold()
                }
            }
            true
        }
    }

    private fun beginHold() {
        if (holding) return
        holding = true
        val loc = IntArray(2)
        targetView.getLocationOnScreen(loc)
        holdX = loc[0] + targetView.width / 2f
        holdY = loc[1] + targetView.height / 2f
        // let the finger-down pass through the target to the app underneath
        targetLp.flags = targetLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(targetView, targetLp)
        handleView.alpha = 1f
        sendChunk(first = true)
    }

    private fun endHold() {
        if (!holding) return
        holding = false   // next chunk callback sends the final "finger up"
        handleView.alpha = 0.55f
        targetLp.flags = targetLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(targetView, targetLp)
    }

    private fun sendChunk(first: Boolean) {
        val path = Path().apply { moveTo(holdX, holdY) }
        val s = if (first || stroke == null)
            GestureDescription.StrokeDescription(path, 0, chunkMs, true)
        else
            stroke!!.continueStroke(path, 0, if (holding) chunkMs else 10L, holding)
        stroke = if (holding) s else null
        val g = GestureDescription.Builder().addStroke(s).build()
        dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                if (stroke != null) sendChunk(first = false)
            }
            override fun onCancelled(d: GestureDescription?) { stroke = null }
        }, null)
    }

    private fun newParams(size: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        size, size,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun circle(color: String, alphaValue: Float) = View(this).apply {
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(color))
            setStroke(4, Color.WHITE)
        }
        alpha = alphaValue
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { endHold() }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        holding = false; stroke = null
        runCatching { wm.removeView(handleView) }
        runCatching { wm.removeView(targetView) }
        super.onDestroy()
    }
}
