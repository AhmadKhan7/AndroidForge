# InstaSpeed (Android prototype)

A personal Android prototype that displays a draggable floating `2×` control only while Instagram is in the foreground. Tapping the control asks Android Accessibility to dispatch a 59-second press-and-hold at the right edge of the screen, where Instagram Reels' native 2× gesture is expected to work.

## Build

1. Open this folder in Android Studio.
2. Allow Gradle sync. The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.
3. Connect the Pixel 8 with USB debugging enabled.
4. Press Run, or use Build > Build APK(s).
5. Open InstaSpeed once.
6. Tap **Enable InstaSpeed**.
7. In Android Accessibility settings, enable **InstaSpeed control**.
8. Open Instagram Reels. The floating `2×` button should appear.

## Controls

- Tap `2×`: sends a long press near the right edge for up to 59 seconds.
- Tap `2× ON`: cancels the active hold.
- Drag the button: reposition it.

## Prototype limitations

- Instagram does not expose a public playback-speed API. This prototype relies on Instagram's native press-and-hold gesture and Android's accessibility gesture dispatch.
- The gesture duration is limited to 59 seconds. It does not automatically chain holds.
- Instagram may change the gesture's hit area or behavior in an update. If the control does not activate 2×, the target coordinate or gesture needs adjustment.
- This app does not read Instagram messages, credentials, or account data.
- Android may show an accessibility-service indicator while enabled.

## Compatibility

Minimum Android 8.0 (API 26). Compile SDK 35. Intended for personal testing on a Pixel 8.
