package com.personal.instaspeed

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import kotlin.math.abs

class SpeedAccessibilityService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var gestureActive = false
    private var instagramVisible = false
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private val holdDurationMs = 59_000L

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        updateInstagramVisibility()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()
        if (pkg == "com.instagram.android") {
            showBubble()
        } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                   event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED) {
            hideBubble()
        }
    }

    override fun onInterrupt() {
        cancelHold()
        hideBubble()
    }

    override fun onDestroy() {
        cancelHold()
        hideBubble()
        super.onDestroy()
    }

    private fun updateInstagramVisibility() {
        val activePackage = rootInActiveWindow?.packageName?.toString()
        if (activePackage == "com.instagram.android") showBubble() else hideBubble()
    }

    private fun showBubble() {
        if (bubble != null) return
        instagramVisible = true

        val button = TextView(this).apply {
            text = "2×"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            alpha = 0.88f
            setBackgroundColor(0xCC202020.toInt())
            setPadding(dp(13), dp(10), dp(13), dp(10))
            elevation = dp(8).toFloat()
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth() - dp(68)
            y = screenHeight() - dp(230)
        }

        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) + abs(dy) > dp(5)) {
                        params.x = (startX + dx).coerceIn(0, screenWidth() - view.width)
                        params.y = (startY + dy).coerceIn(0, screenHeight() - view.height)
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = abs(event.rawX - downX)
                    val dy = abs(event.rawY - downY)
                    if (dx + dy <= dp(8)) toggleHold()
                    true
                }
                else -> true
            }
        }

        bubble = button
        bubbleParams = params
        try {
            windowManager.addView(button, params)
        } catch (_: Exception) {
            bubble = null
            bubbleParams = null
        }
    }

    private fun hideBubble() {
        instagramVisible = false
        bubble?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubble = null
        bubbleParams = null
        cancelHold()
    }

    private fun toggleHold() {
        if (gestureActive) {
            cancelHold()
            return
        }

        // Instagram Reels recognizes a press-and-hold near either screen edge.
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val x = (metrics.widthPixels - dp(8)).toFloat()
        val y = (metrics.heightPixels * 0.50f)

        val path = Path().apply {
            moveTo(x, y)
            lineTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, holdDurationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        gestureActive = true
        bubble?.text = "2× ON"
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureActive = false
                bubble?.text = "2×"
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureActive = false
                bubble?.text = "2×"
            }
        }, null)

        if (!accepted) {
            gestureActive = false
            bubble?.text = "2×"
        }
    }

    private fun cancelHold() {
        if (gestureActive) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) cancelGesture()
            gestureActive = false
        }
        bubble?.text = "2×"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun screenWidth(): Int = resources.displayMetrics.widthPixels
    private fun screenHeight(): Int = resources.displayMetrics.heightPixels
}
