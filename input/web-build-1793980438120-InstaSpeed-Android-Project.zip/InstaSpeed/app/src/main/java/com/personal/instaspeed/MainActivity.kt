package com.personal.instaspeed

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
        }

        val title = TextView(this).apply {
            text = "InstaSpeed"
            textSize = 28f
        }
        val info = TextView(this).apply {
            text = "Enable the accessibility service below. The floating 2× button appears only while Instagram is open. Tap it to send Instagram’s native press-and-hold gesture."
            textSize = 16f
            setPadding(0, 20, 0, 24)
        }
        val enable = Button(this).apply {
            text = "Enable InstaSpeed"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val note = TextView(this).apply {
            text = "The first prototype holds the gesture for up to 59 seconds. Instagram controls playback speed; this app does not modify Instagram or access your account."
            textSize = 14f
            setPadding(0, 20, 0, 0)
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(enable)
        layout.addView(note)
        setContentView(layout)
    }
}
