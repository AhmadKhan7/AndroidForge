package com.example.floattap

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(ClickService.PREFS, Context.MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        toggle = Switch(this).apply {
            textSize = 22f
            isChecked = prefs.getBoolean(ClickService.KEY_ENABLED, true)
            text = label(isChecked)
            setOnCheckedChangeListener { _, on ->
                text = label(on)
                prefs.edit().putBoolean(ClickService.KEY_ENABLED, on).apply()
            }
        }
        layout.addView(toggle)

        status = TextView(this).apply { textSize = 16f; setPadding(0, 24, 0, 24) }
        layout.addView(status)

        layout.addView(TextView(this).apply {
            text = "1. Tap below and enable \"FloatTap\" under Accessibility.\n" +
                   "2. Two floating buttons appear (use the switch above to hide/show them).\n" +
                   "3. Drag the red circle onto the right side of a Reel. Both circles can go anywhere on screen.\n" +
                   "4. Press and hold the green circle = hold the red spot (2x) while pressed; let go = 1x.\n" +
                   "5. Quick tap on the green circle = toggle 2x on/off (stays on until you tap again)."
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (ClickService.running) "Service: running"
        else "Service: NOT running - enable FloatTap in Accessibility settings"
    }

    private fun label(on: Boolean) = if (on) "Floating buttons: ON" else "Floating buttons: OFF"
}
