package com.example.floattap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.max

/**
 * Two floating buttons:
 *  - HANDLE (green): one tap = start holding the target spot (2x). Tap again = stop (normal speed).
 *  - TARGET (red): drag it onto the video (right side of a Reel = 2x speed).
 * Both can be dragged ANYWHERE on the screen (status bar / nav bar area included).
 * The on/off switch lives in the app (MainActivity) and is stored in SharedPreferences.
 * Touching the screen anywhere else while 2x is on also releases the hold.
 */
class ClickService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        const val PREFS = "floattap"
        const val KEY_ENABLED = "enabled"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private lateinit var handleView: View
    private lateinit var targetView: View
    private lateinit var handleBg: GradientDrawable
    private lateinit var handleLp: LP
    private lateinit var targetLp: LP
    private val ui = Handler(Looper.getMainLooper())

    private var density = 1f
    private var shown = false

    private var holding = false          // hold is logically on
    private var stroke: GestureDescription.StrokeDescription? = null  // finger is down while non-null
    private var holdX = 0f
    private var holdY = 0f
    private val chunkMs = 250L

    private var handleDown = false       // real finger currently on the handle
    private var handleTouchTime = 0L    // uptime of the last finger-down on the handle

    override fun onServiceConnected() {
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        density = resources.displayMetrics.density

        val handleSize = (72 * density).toInt()
        val targetSize = (56 * density).toInt()
        val (w, h) = screenSize()
        handleLp = newParams(handleSize, w - handleSize, (h * 0.62).toInt())
        targetLp = newParams(targetSize, w - handleSize, (h * 0.40).toInt())

        handleBg = oval("#2E7D32")
        handleView = View(this).apply { background = handleBg; alpha = 0.55f }
        targetView = View(this).apply { background = oval("#C62828"); alpha = 0.85f }

        installTouch(
            targetView, targetLp
        )
        installTouch(
            handleView, handleLp,
            onDown = { handleDown = true; handleTouchTime = SystemClock.uptimeMillis() },
            onRelease = { handleDown = false },
            onTap = { if (holding) stopHold() else startHold() },   // tap: toggle 2x on / off
            onDragStart = { if (holding) stopHold() },
            onCancel = { stopHold() }
        )

        prefs.registerOnSharedPreferenceChangeListener(this)
        applyEnabled()
    }

    // ---------- on / off (switch in the app) ----------

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key == KEY_ENABLED) ui.post { applyEnabled() }
    }

    private fun applyEnabled() {
        if (prefs.getBoolean(KEY_ENABLED, true)) show() else hide()
    }

    private fun show() {
        if (shown) return
        shown = true
        clamp(targetLp); clamp(handleLp)
        wm.addView(targetView, targetLp)
        wm.addView(handleView, handleLp)
    }

    private fun hide() {
        if (!shown) return
        stopHold()
        shown = false
        runCatching { wm.removeView(handleView) }
        runCatching { wm.removeView(targetView) }
    }

    // ---------- dragging (works anywhere on screen) ----------

    private fun installTouch(
        view: View, lp: LP,
        onDown: () -> Unit = {},
        onTap: () -> Unit = {},
        onDragStart: () -> Unit = {},
        onCancel: () -> Unit = {},
        onRelease: () -> Unit = {}
    ) {
        val slop = 10 * density
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var dragging = false
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; dragging = false
                    onDown()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) {
                        dragging = true
                        onDragStart()
                    }
                    if (dragging) {
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        clamp(lp)
                        update(view, lp)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    onRelease()
                    if (dragging) {
                        separate(view, lp)
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        onTap()
                    } else {
                        onCancel()
                    }
                }
            }
            true
        }
    }

    private fun update(view: View, lp: LP) {
        if (shown) runCatching { wm.updateViewLayout(view, lp) }
    }

    /** Real screen size, including status bar and navigation bar. */
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val p = Point()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
            p.x to p.y
        }

    private fun clamp(lp: LP) {
        val (w, h) = screenSize()
        lp.x = lp.x.coerceIn(0, max(0, w - lp.width))
        lp.y = lp.y.coerceIn(0, max(0, h - lp.height))
    }

    /**
     * The two buttons must never sit on top of each other, otherwise the green handle would
     * swallow the press meant for the app under the red target. If the one just moved overlaps
     * the other, nudge it sideways to the nearest free spot.
     */
    private fun separate(moved: View, lp: LP) {
        val o = if (moved === handleView) targetLp else handleLp
        val gap = (8 * density).toInt()
        val overlaps = lp.x < o.x + o.width + gap && o.x < lp.x + lp.width + gap &&
                lp.y < o.y + o.height + gap && o.y < lp.y + lp.height + gap
        if (!overlaps) return
        val (w, _) = screenSize()
        val maxX = max(0, w - lp.width)
        val candidates = listOf(o.x + o.width + gap, o.x - lp.width - gap).filter { it in 0..maxX }
        val best = candidates.minByOrNull { abs(it - lp.x) } ?: return
        lp.x = best
        update(moved, lp)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!shown) return
        ui.post {
            clamp(targetLp); clamp(handleLp)
            update(targetView, targetLp); update(handleView, handleLp)
        }
    }

    // ---------- hold ----------

    private fun startHold() {
        if (holding || !shown || stroke != null) return
        if (!handleDown) separate(handleView, handleLp)
        val loc = IntArray(2)
        targetView.getLocationOnScreen(loc)
        holdX = loc[0] + targetView.width / 2f
        holdY = loc[1] + targetView.height / 2f
        holding = true
        setHandleActive(true)
        // the finger-down must pass THROUGH the red target to the app underneath
        setTargetTouchable(false)
        ui.postDelayed({ if (holding && stroke == null) sendChunk(first = true) }, 80L)
    }

    private fun stopHold() {
        if (!holding) return
        holding = false
        setHandleActive(false)
        setTargetTouchable(true)
        // if a stroke is in flight, its completion callback sends the final "finger up"
    }

    private fun setHandleActive(on: Boolean) {
        handleBg.setColor(Color.parseColor(if (on) "#00E676" else "#2E7D32"))
        handleView.alpha = if (on) 1f else 0.55f
    }

    private fun setTargetTouchable(touchable: Boolean) {
        targetLp.flags = if (touchable) targetLp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
        else targetLp.flags or LP.FLAG_NOT_TOUCHABLE
        update(targetView, targetLp)
    }

    private fun sendChunk(first: Boolean) {
        val path = Path().apply { moveTo(holdX, holdY) }
        val prev = stroke
        val s = if (first || prev == null)
            GestureDescription.StrokeDescription(path, 0, chunkMs, true)
        else
            prev.continueStroke(path, 0, chunkMs, true)
        stroke = s
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(s).build(),
            object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) {
                    if (stroke == null) return
                    if (holding) sendChunk(first = false) else sendFinal()
                }

                override fun onCancelled(d: GestureDescription?) {
                    stroke = null
                    // Android cancelled it because a real finger touched the screen elsewhere.
                    // Touching the handle itself is handled by its own tap logic.
                    if (holding) {
                        if (!handleDown) {
                            // The cancel can arrive just BEFORE the handle's own touch event when you
                            // tap the handle to switch off. Wait a moment and only release if the
                            // handle was not touched around that time.
                            val t0 = SystemClock.uptimeMillis()
                            ui.postDelayed({
                                if (holding && !handleDown && handleTouchTime < t0 - 250L) {
                                    holding = false
                                    setHandleActive(false)
                                    setTargetTouchable(true)
                                }
                            }, 250L)
                        }
                    }
                }
            }, null
        )
        if (!ok) {
            stroke = null
            holding = false
            setHandleActive(false)
            setTargetTouchable(true)
        }
    }

    private fun sendFinal() {
        val prev = stroke ?: return
        stroke = null
        val path = Path().apply { moveTo(holdX, holdY) }
        val s = prev.continueStroke(path, 0, 10L, false)
        dispatchGesture(GestureDescription.Builder().addStroke(s).build(), null, null)
    }

    // ---------- misc ----------

    private fun newParams(size: Int, x: Int, y: Int) = LP(
        size, size,
        LP.TYPE_ACCESSIBILITY_OVERLAY,
        LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCH_MODAL or
                LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x; this.y = y
        if (Build.VERSION.SDK_INT >= 30) layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun oval(color: String) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.parseColor(color))
        setStroke(4, Color.WHITE)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopHold() }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        runCatching { prefs.unregisterOnSharedPreferenceChangeListener(this) }
        holding = false; stroke = null
        shown = false
        runCatching { wm.removeView(handleView) }
        runCatching { wm.removeView(targetView) }
        super.onDestroy()
    }
}
